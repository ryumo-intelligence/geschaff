package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.BookDAO;
import dao.OrderDAO;

public class ShowCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";
		String cmd = "";


		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			String delno = request.getParameter("delno");

			//セッションオブジェクト生成
			HttpSession session = request.getSession();

			//セッションから取得
			User user = (User)session.getAttribute("user");
			if(user == null) {
				error = "セッション切れの為、カート状況は確認できません。";
				cmd = "logout";
				return;
			}

			//セッションからorderlist取得
			ArrayList<Order> order_list = (ArrayList<Order>)session.getAttribute("order_list");

			if(delno == null) {
				order_list.remove(Integer.parseInt(delno));
				session.setAttribute("order_list", order_list);
			}

			//格納用配列
			ArrayList<Book> list = new ArrayList<Book>();

			//オブジェクト生成
			BookDAO objDao = new BookDAO();

			if (order_list != null) {
				for (Order order : order_list) {
					Book book = objDao.selectByIsbn(order.getIsbn());
					list.add(book);
				}
			}

			request.setAttribute("book_list",list);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、カート状況は確認できません。";
			cmd = "logout";

		}catch(Exception e){
			error ="予期せぬエラーが発生しました。<br>"+e;
			cmd = "logout";

		}finally {

			if(error.equals("")) {
				//フォワードの実行
				request.getRequestDispatcher("/view/showCart.jsp").forward(request, response);
			}
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}
	}

}
