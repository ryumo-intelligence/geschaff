package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.BookDAO;

public class InsertIntoCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";
		String cmd = "";


		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//セッションオブジェクト生成
			HttpSession session = request.getSession();

			//セッションからオブジェクト取得
			User user = (User)session.getAttribute("user");

			if(user == null) {
				error = "セッション切れの為、カートに追加できません。";
				cmd = "logout";
				return;
			}

			//入力パラメータの取得
			String isbn = (String) request.getParameter("isbn");

			//オブジェクト生成
			BookDAO objDao = new BookDAO();
			Book book = objDao.selectByIsbn(isbn);

			//リクエストスコープに登録
			request.setAttribute("Book", book);

			Order order = new Order();
			order.setUserid(user.getUserid());
			order.setIsbn(book.getIsbn());
			order.setQuantity(1);


			ArrayList<Order> order_list = new ArrayList<Order>();
			order_list = (ArrayList<Order>)session.getAttribute("order_list");

			if(order_list == null) {
				order_list = new ArrayList<Order>();
			}

			order_list.add(order);
			session.setAttribute("order_list",order_list);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、カートに追加出来ません。";
			cmd = "logout";

		}catch(Exception e){
			error ="予期せぬエラーが発生しました。<br>"+e;
			cmd = "logout";

		}finally {

			if(error.equals("")) {
				//フォワードの実行
				request.getRequestDispatcher("/view/insertIntoCart.jsp").forward(request, response);
			}
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}

	}
}