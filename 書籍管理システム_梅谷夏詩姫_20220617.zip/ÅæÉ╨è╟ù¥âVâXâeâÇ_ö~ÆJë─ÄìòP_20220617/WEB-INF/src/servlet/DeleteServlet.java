package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.Book;
import dao.BookDAO;

public class DeleteServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			String isbn = request.getParameter("isbn");

			//オブジェクトインスタンス化
			BookDAO objDao = new BookDAO();

			//ISBNチェック
			if (objDao.selectByIsbn(isbn).getIsbn() == null) {
				error = "削除対象の書籍が存在しない為、書籍削除処理は行えませんでした。";
				cmd = "list";
				return;
			}

			//削除メソッド呼び出し
			objDao.delete(isbn);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、書籍削除処理は行えませんでした。";
			cmd = "menu";

		}catch(Exception e){
			error ="予期せぬエラーが発生しました。<br>"+e;
			cmd = "menu";

		}finally {
			if(error.equals("")) {
				//フォワードの実行
				request.getRequestDispatcher("/list").forward(request, response);
			}
			else{
				request.setAttribute("error",error);
				request.getRequestDispatcher("view/error.jsp").forward(request, response);
			}

		}
	}


}
