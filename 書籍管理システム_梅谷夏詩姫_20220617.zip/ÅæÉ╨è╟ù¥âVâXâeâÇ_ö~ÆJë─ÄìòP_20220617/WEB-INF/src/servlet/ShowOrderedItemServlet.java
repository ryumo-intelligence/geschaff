package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.*;

public class ShowOrderedItemServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";
		String cmd = "";


		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//メソッドを呼び出す
			OrderedItemDAO orderedItemDao = new OrderedItemDAO();

			//リストを取得する
			ArrayList<OrderedItem> list = orderedItemDao.selectAll();


			//リクエストスコープに登録
			request.setAttribute("ordered_list",list);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、購入状況確認でできません。";
			cmd = "logout";

		}catch(Exception e){
			error ="予期せぬエラーが発生しました。";
			cmd = "logout";

		}finally {

			if(error.equals("")) {
				//フォワードの実行
				request.getRequestDispatcher("/view/showOrderedItem.jsp").forward(request, response);
			}
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}
	}

}
