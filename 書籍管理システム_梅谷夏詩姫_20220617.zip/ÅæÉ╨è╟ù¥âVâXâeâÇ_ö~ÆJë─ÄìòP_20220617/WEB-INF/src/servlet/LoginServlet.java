package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.UserDAO;

public class LoginServlet extends HttpServlet {

	public void doPost(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";
		String cmd = "";
		String userid = "";
		String password = "";

		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			userid = request.getParameter("user");
			password = request.getParameter("password");

			//オブジェクト生成
			UserDAO userobjDao = new UserDAO();

			//メソッド呼び出し
			User user = userobjDao.selectByUser(userid,password);

			if(user.getUserid() == null || user.getPassword() == null) {
				error = "入力データが間違っています。";
				cmd = "login";
				return;
			}

			//セッション登録
			HttpSession session = request.getSession();
			session.setAttribute("user", user);

			//クッキー登録
			Cookie userCookie = new Cookie("user", user.getUserid());
			userCookie.setMaxAge(60*60*24*5);
			response.addCookie(userCookie);

			Cookie passwordCookie = new Cookie("password", user.getPassword());
			passwordCookie.setMaxAge(60*60*24*5);
			response.addCookie(passwordCookie);


		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、ログインはできません。";
			cmd = "login";

		}catch(Exception e){
			error ="予期せぬエラーが発生しました。<br>"+e;
			cmd = "login";

		}finally {
			if(error.equals("")) {
				//フォワードの実行
				request.getRequestDispatcher("/view/menu.jsp").forward(request, response);

			}else {
				request.setAttribute("error", error);
				if (cmd.equals("login")) {
					request.getRequestDispatcher("/view/login.jsp").forward(request, response);

				}else {
					request.setAttribute("error", error);
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/login.jsp").forward(request, response);
				}
			}
		}
	}
}

