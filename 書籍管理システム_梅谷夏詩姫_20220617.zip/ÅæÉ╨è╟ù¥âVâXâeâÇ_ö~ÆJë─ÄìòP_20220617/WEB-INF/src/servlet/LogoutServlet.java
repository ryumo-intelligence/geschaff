package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LogoutServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{


		//セッション情報をクリア
		HttpSession session = request.getSession();

		if (session != null) {
			session.invalidate();
		}

		//フォワードの実行
		request.getRequestDispatcher("/view/login.jsp").forward(request, response);
	}

}
