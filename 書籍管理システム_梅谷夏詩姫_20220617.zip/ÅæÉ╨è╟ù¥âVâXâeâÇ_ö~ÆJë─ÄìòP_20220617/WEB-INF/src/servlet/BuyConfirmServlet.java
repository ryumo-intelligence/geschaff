package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.*;
import util.SendMail;

public class BuyConfirmServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";
		String cmd = "";


		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//セッションオブジェクト生成
			HttpSession session = request.getSession();

			//セッションから取得
			User user = (User)session.getAttribute("user");

			//セッション切れだった場合
			if(user == null) {
				error = "セッション切れの為、メニュー画面が表示できませんでした。";
				cmd = "logout";
				return;
			}


			ArrayList<Order> order_list = (ArrayList<Order>)session.getAttribute("order_list");

			//カートの中に何もなかった場合
			if(order_list == null || order_list.isEmpty()) {
				error = "カートの中に何もなかったので購入はできません。";
				cmd = "menu";
				return;
			}

			//DAO宣言
			BookDAO objDao = new BookDAO();
			OrderDAO orderDao = new OrderDAO();

			//格納用配列
			ArrayList<Book> book_list = new ArrayList<Book>();

			for (Order order : order_list) {
				Book book = objDao.selectByIsbn(order.getIsbn());
				book_list.add(book);
				orderDao.insert(order);
			}

			request.setAttribute("book_list",book_list);

			//メール送信
			//オブジェクト生成
			SendMail sendMail = new SendMail();

			sendMail.setFromInfo("info@kanda-it-school.com", "書籍管理システム");
			sendMail.setRecipients(user.getEmail());
			sendMail.setSubject("本のご購入ありがとうございます。");
			sendMail.setText(user.getUserid()
					+ "様\n\n本のご購入ありがとうございます。\n以下内容でご注文を受け付けましたので、ご連絡致します。\n");

			int sum = 0;
			for (Book book : book_list) {
				sendMail.setText(book.getIsbn() + " " + book.getTitle() + " "
						+ book.getPrice() + "円");
				sum += book.getPrice();
			}

			sendMail.setText("合計 " + sum + "円\n\nまたのご利用よろしくお願いします。");
			sendMail.forwardMail();

			// セッションのorder_listをクリア
			session.setAttribute("order_list", null);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、登録できませんでした。";
			cmd = "logout";

		}catch(Exception e){
			error ="予期せぬエラーが発生しました。<br>"+e;
			cmd = "logout";

		}finally {

			if(error.equals("")) {
				//フォワードの実行
				request.getRequestDispatcher("/view/buyConfirm.jsp").forward(request, response);
			}
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}

	}

}
