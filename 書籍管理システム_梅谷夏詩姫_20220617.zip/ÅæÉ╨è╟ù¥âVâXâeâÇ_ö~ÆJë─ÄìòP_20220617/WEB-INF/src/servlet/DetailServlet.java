package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.Book;
import dao.BookDAO;

public class DetailServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			String isbn = request.getParameter("isbn");
			cmd = request.getParameter("cmd");

			//BookDaoインスタンス化
			BookDAO objDao = new BookDAO();
			Book book = objDao.selectByIsbn(isbn);

			//ISBNチェック
			if(book.getIsbn() == null) {
				error = "表示対象の書籍が存在しない為、詳細情報は表示できませんでした。";
				cmd = "list";
				return;
			}

			//リクエストスコープに登録
			request.setAttribute("Book", book);

		}catch(IllegalStateException e) {
			if (cmd.equals("detail")) {
				error = "DB接続エラーの為、書籍詳細は表示出来ませんでした。";
			} else if (cmd.equals("update")) {
				error = "DB接続エラーの為、変更画面は表示できませんでした。";
			}
			cmd = "menu";

		}catch(Exception e){
			error ="予期せぬエラーが発生しました。<br>"+e;
			cmd = "menu";

		}finally {

			if(error.equals("")) {
				//フォワードの実行
				if(cmd.equals("detail")){
					request.getRequestDispatcher("/view/detail.jsp").forward(request, response);
				}else if(cmd.equals("update")){
					request.getRequestDispatcher("/view/update.jsp").forward(request,response);

				}else {
					request.setAttribute("error", error);
					request.setAttribute("cmd", cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}

			}

		}

	}

}
