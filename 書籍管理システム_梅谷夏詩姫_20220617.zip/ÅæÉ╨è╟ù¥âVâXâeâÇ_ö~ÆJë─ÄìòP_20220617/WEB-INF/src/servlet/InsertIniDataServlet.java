package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.*;
import dao.*;
import util.FileIn;


public class InsertIniDataServlet extends HttpServlet {


	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";
		String cmd = "";
		FileIn in = new FileIn();


		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//インスタンス化しメソッド呼び出し
			BookDAO objDao = new BookDAO();

			//リストを取得
			ArrayList<Book> list = objDao.selectAll();

			//DBにデータがあった場合
			if(!list.isEmpty()) {
				error = "DBにはデータが存在するので、初期データ登録は行えません。";
				cmd = "menu";
				return;
			}

			//csvファイルを取得する
			String path = getServletContext().getRealPath("file\\initial_data.csv");

			//csvファイルがなかった場合
			if(!(in.open(path))) {
				error = "初期データファイルがないため、登録は行えません";
				cmd = "menu";
				return;
			}


			String str = null;
			while ((str = in.readLine()) != null) {

				String[] data = str.split(",");

				Book book = new Book();
				book.setIsbn(data[0]);
				book.setTitle(data[1]);
				book.setPrice(Integer.parseInt(data[2]));

				// 取得した各BookをListに追加
				list.add(book);
			}

			//リスエストスコープに格納
			request.setAttribute("book_list",list);

			//オブジェクト生成しメソッド呼び出し
			for (Book book : list) {
				objDao.insert(book);
			}

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、初期データ登録は行えません。";
			cmd = "logout";


		} catch (NumberFormatException e) {
			error = "初期データに不備がある為、登録は行えません。";
			cmd = "menu";

		}finally {

			// ファイルのクローズ
			in.close();

			if(error.equals("")) {
				//フォワードの実行
				request.getRequestDispatcher("/view/insertIniData.jsp").forward(request, response);
			}
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}

	}


}
