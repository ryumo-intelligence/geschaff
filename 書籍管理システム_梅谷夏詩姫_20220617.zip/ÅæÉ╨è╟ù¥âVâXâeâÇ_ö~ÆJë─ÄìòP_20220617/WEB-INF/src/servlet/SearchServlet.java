package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.Book;
import dao.BookDAO;

public class SearchServlet extends HttpServlet {

	public void doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {
			// 文字コードを設定
			request.setCharacterEncoding("UTF-8");

			//オブジェクト宣言
			BookDAO objDao = new BookDAO();

			//パラメータの取得
			String isbn = request.getParameter("isbn");
			String title = request.getParameter("title");
			String strPrice = request.getParameter("price");

			//配列宣言
			ArrayList<Book> list = new ArrayList<Book>();

			//bookオブジェクトのリストを取得
			list = objDao.search(isbn, title, strPrice);

			//リクエストスコープに登録
			request.setAttribute("book_list", list);



		}catch(IllegalStateException e){

			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "menu";

		}catch(Exception e){
			error ="予期せぬエラーが発生しました。<br>"+e;
			cmd = "menu";

		}finally {
			if(error.equals("")) {
				//フォワード
				request.getRequestDispatcher("/view/list.jsp").forward(request, response);
			}else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}

}
