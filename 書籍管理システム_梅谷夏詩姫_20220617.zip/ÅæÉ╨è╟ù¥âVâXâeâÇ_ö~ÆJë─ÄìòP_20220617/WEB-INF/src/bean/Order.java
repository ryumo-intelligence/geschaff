package bean;

public class Order {

	//変数定義
	private int orderno;
	private String userid;
	private String isbn;
	private int quantity;
	private String date;

	public Order(){
		//変数初期化
		orderno = 0;
		userid = null;
		isbn = null;
		quantity = 0;
		date = null;

	}

	//各フィールド変数のSetメソッドを定義
	public void setOrderNo(int orderno){
		this.orderno = orderno;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setDate(String date) {
		this.date = date;
	}

	//各フィールド変数のGetメソッドを定義
	public int getOrderNo() {
		return this.orderno;
	}

	public String getUserid() {
		return this.userid;
	}

	public String getIsbn() {
		return this.isbn;
	}

	public int getQuantity() {
		return this.quantity;
	}

	public String getDate() {
		return this.date;
	}

}
