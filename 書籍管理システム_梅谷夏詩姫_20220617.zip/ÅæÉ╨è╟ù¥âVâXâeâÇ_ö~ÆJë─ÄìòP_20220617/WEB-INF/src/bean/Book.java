package bean;

public class Book {

	//フィールド変数宣言
	private String isbn;
	private String title;
	private int price;

	public Book(){
		//コンストラクタ定義
		this.isbn = null;
		this.title = null;
		this.price = 0;
	}

	//各フィールド変数のSetメソッドを定義
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setPrice(int price) {
		this.price = price;
	}


	//各フィールド変数のGetメソッドを定義
	public String getIsbn() {
		return this.isbn;
	}

	public String getTitle() {
		return this.title;
	}

	public int getPrice() {
		return this.price;
	}
}
