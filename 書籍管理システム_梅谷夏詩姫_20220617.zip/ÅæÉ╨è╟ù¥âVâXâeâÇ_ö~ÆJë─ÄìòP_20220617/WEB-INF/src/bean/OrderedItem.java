package bean;

public class OrderedItem {

	//変数宣言
	private String userid;
	private String title;
	private String date;

	public OrderedItem(){
		//変数初期化
		userid = null;
		title = null;
		date = null;
	}

	//各フィールド変数のSetメソッドを定義
	public void setUserid(String userid) {
		this.userid = userid;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDate(String date) {
		this.date = date;
	}

	//各フィールド変数のGetメソッドを定義
	public String getUserid() {
		return this.userid;
	}

	public String getTitle() {
		return this.title;
	}

	public String getDate() {
		return this.date;
	}
}
