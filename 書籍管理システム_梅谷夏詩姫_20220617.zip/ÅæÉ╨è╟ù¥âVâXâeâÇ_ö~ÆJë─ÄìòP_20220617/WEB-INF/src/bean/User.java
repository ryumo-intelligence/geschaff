package bean;

public class User {

	//フィールド変数定義
	private String userid;
	private String password;
	private String email;
	private String authority;

	public User(){
		//コンストラクタ定義
		this.userid = null;
		this.password = null;
		this.email = null;
		this.authority = null;
	}

	//各フィールド変数のSetメソッドを定義
	public void setUserid(String userid) {
		this.userid = userid;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

	//各フィールド変数のGetメソッドを定義
	public String getUserid() {
		return this.userid;
	}

	public String getPassword() {
		return this.password;
	}

	public String getEmail() {
		return this.email;
	}

	public String getAuthority() {
		return this.authority;
	}

}
