package dao;

import java.sql.*;
import java.util.*;
import bean.*;

public class UserDAO {

	//DB情報をフィールド変数に定義
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/mybookdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	//DB接続を行うメソッド
	public static Connection getConnection() {

		Connection con = null;
		try{
			//JDBCをオーバーロードする
			Class.forName(RDB_DRIVE);

			//オブジェクト生成
			con = DriverManager.getConnection(URL, USER, PASSWD);

			//オブジェクトをリターンする
			return con;
		}catch(Exception e){
			throw new IllegalStateException(e);
		}
	}



	//passとid情報が合致した場合の情報取得
	public User selectByUser(String userid, String password) {

		//オブジェクト生成
		User user = new User();

		//変数宣言
		Connection con = null;
		Statement  smt = null;

		//SQL文を文字列として定義
		String sql = "SELECT * FROM userinfo WHERE user = '" + userid + "' AND password = '" + password + "'";


		try{

			//Connectionオブジェクトを生成
			con = BookDAO.getConnection();

			//Statementオブジェクトを生成
			smt = con.createStatement();

			//SQL文を発行
			ResultSet rs = smt.executeQuery(sql);


			if (rs.next()) {
				user.setUserid(rs.getString("user"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setAuthority(rs.getString("authority"));
			}

		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{

			//Statementオブジェクトをクローズ
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}

			//Connectionオブジェクトをクローズ
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}

		//userを返す
		return user;
	}

}
