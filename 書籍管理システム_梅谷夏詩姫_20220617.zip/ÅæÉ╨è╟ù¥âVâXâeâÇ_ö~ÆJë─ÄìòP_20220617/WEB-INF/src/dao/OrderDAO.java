package dao;

import java.sql.*;
import java.util.*;
import bean.*;


public class OrderDAO {

	//DB情報をフィールド変数に定義
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/mybookdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	//DB接続を行うメソッド
	public static Connection getConnection() {

		Connection con = null;

		try{
			//JDBCをオーバーロードする
			Class.forName(RDB_DRIVE);

			//オブジェクト生成
			con = DriverManager.getConnection(URL, USER, PASSWD);

			//オブジェクトをリターンする
			return con;
		}catch(Exception e){
			throw new IllegalStateException(e);
		}
	}

	public void insert(Order order) {

		//sqlを文字列として定義
		String sql = "INSERT INTO orderinfo VALUES(NULL,'"+ order.getUserid() + "','"+ order.getIsbn() +"',"
				+ order.getQuantity() +",CURDATE())";

		//変数宣言
		Connection con = null;
		Statement  smt = null;

		try{

			//Connectionオブジェクトを生成
			con = BookDAO.getConnection();

			//Statementオブジェクトを生成
			smt = con.createStatement();

			//SQL文を発行
			smt.executeUpdate(sql);

		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{

			//Statementオブジェクトをクローズ
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}

			//Connectionオブジェクトをクローズ
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}


	}



}
