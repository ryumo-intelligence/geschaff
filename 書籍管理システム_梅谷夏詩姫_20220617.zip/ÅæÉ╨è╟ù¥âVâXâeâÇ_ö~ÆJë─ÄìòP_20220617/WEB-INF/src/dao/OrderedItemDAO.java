package dao;

import java.sql.*;
import java.util.*;
import bean.*;

public class OrderedItemDAO {

	//DB情報をフィールド変数に定義
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/mybookdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	//DB接続を行うメソッド
	public static Connection getConnection() {

		Connection con = null;

		try{
			//JDBCをオーバーロードする
			Class.forName(RDB_DRIVE);

			//オブジェクト生成
			con = DriverManager.getConnection(URL, USER, PASSWD);

			//オブジェクトをリターンする
			return con;
		}catch(Exception e){
			throw new IllegalStateException(e);
		}
	}

	//購入情報取得
	public static ArrayList<OrderedItem> selectAll(){

		//オブジェクト生成
		ArrayList<OrderedItem> ordered_list = new ArrayList<OrderedItem>();

		//SQL文を文字列として定義
		String sql =  "SELECT o.user,b.title,o.date FROM bookinfo b INNER JOIN orderinfo o ON b.isbn=o.isbn";

		//変数宣言
		Connection con = null;
		Statement  smt = null;

		try{

			//Connectionオブジェクトを生成
			con = BookDAO.getConnection();

			//Statementオブジェクトを生成
			smt = con.createStatement();

			//SQL文を発行
			ResultSet rs = smt.executeQuery(sql);

			//書籍データを配列に格納
			while (rs.next()) {
				OrderedItem orderedItem = new OrderedItem();
				orderedItem.setUserid(rs.getString("user"));
				orderedItem.setTitle(rs.getString("title"));
				orderedItem.setDate(rs.getString("date"));


				ordered_list.add(orderedItem);

			}

		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{

			//Statementオブジェクトをクローズ
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}

			//Connectionオブジェクトをクローズ
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}

		return ordered_list;
	}

}
