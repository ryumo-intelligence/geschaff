package dao;

import java.sql.*;
import java.util.*;
import bean.*;

public class BookDAO {

	//DB情報をフィールド変数に定義
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/mybookdb";
	private static String USER = "root";
	private static String PASSWD = "root123";


	//DB接続を行うメソッド
	public static Connection getConnection() {

		try{
			//JDBCをオーバーロードする
			Class.forName(RDB_DRIVE);

			//オブジェクト生成
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);

			//オブジェクトをリターンする
			return con;
		}catch(Exception e){
			throw new IllegalStateException(e);
		}
	}

	//一覧機能
	public ArrayList<Book> selectAll(){

		//検索した書籍情報を格納するオブジェクトを生成
		ArrayList<Book> bookList = new ArrayList<Book>();

		//SQL文を文字列として定義
		String sql = "SELECT isbn,title,price FROM bookinfo ORDER BY isbn";

		//変数宣言
		Connection con = null;
		Statement  smt = null;

		try{

			//Connectionオブジェクトを生成
			con = BookDAO.getConnection();

			//Statementオブジェクトを生成
			smt = con.createStatement();

			//SQL文を発行
			ResultSet rs = smt.executeQuery(sql);

			//書籍データを配列に格納
			while(rs.next()){
				Book book = new Book();
				book.setIsbn(rs.getString("isbn"));
				book.setTitle(rs.getString("title"));
				book.setPrice(rs.getInt("price"));

				//ArrayListオブジェクトにBookオブジェクトとして格納
				bookList.add(book);
			}

		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{

			//Statementオブジェクトをクローズ
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}

			//Connectionオブジェクトをクローズ
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		//listを返す
		return bookList;

	}

	//書籍詳細画面
	public Book selectByIsbn(String isbn) {

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//オブジェクトを生成
		Book book = new Book();

		//SQL文を文字列として定義
		String sql = "SELECT isbn,title,price FROM bookinfo WHERE isbn = '" + isbn + "'";

		try {

			//Connectionオブジェクトを生成
			con = BookDAO.getConnection();

			//Statementオブジェクトを生成
			smt = con.createStatement();

			//SQL文を発行
			ResultSet rs = smt.executeQuery(sql);

			//書籍データを検索分すべて取り出す
			while(rs.next()){
				book.setIsbn(rs.getString("isbn"));
				book.setTitle(rs.getString("title"));
				book.setPrice(rs.getInt("price"));

			}

		}catch(Exception e) {

			throw new IllegalStateException(e);

		}finally {
			//Statementオブジェクトをクローズ
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}

			//Connectionオブジェクトをクローズ
			if(con != null) {
				try {con.close();}catch(SQLException ignore){}
			}

		}
		return book;
	}


	//登録
	public void insert(Book book) {

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//SQL文を文字列として定義
		String sql = "INSERT INTO bookinfo VALUES('" + book.getIsbn()
		+ "','" + book.getTitle()
		+ "','"+ book.getPrice() +"')";

		try {

			//Connectionオブジェクトを生成
			con = BookDAO.getConnection();

			//Statementオブジェクトを生成
			smt = con.createStatement();

			//SQL文を発行
			smt.executeUpdate(sql);


		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {

			//Statementオブジェクトをクローズ
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}

			//Connectionオブジェクトをクローズ
			if(con != null) {
				try {con.close();}catch(SQLException ignore) {}
			}
		}
	}
	//削除
	public void delete(String isbn) {

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//SQL文を文字列として定義
		String sql = "DELETE FROM bookinfo WHERE isbn = '"+ isbn + "'";

		try {

			//Connectionオブジェクトを生成
			con = BookDAO.getConnection();

			//Statementオブジェクトを生成
			smt = con.createStatement();


			//SQL文を発行
			smt.executeUpdate(sql);

		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {

			//Statementオブジェクトをクローズ
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}

			//Connectionオブジェクトをクローズ
			if(con != null) {
				try {con.close();}catch(SQLException ignore) {}
			}
		}
	}

	//更新
	public void update(Book book) {

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//SQL文を文字列として定義
		String sql = "UPDATE bookinfo SET title = '" + book.getTitle()
		+ "', price = " + book.getPrice()
		+ " WHERE isbn = '" + book.getIsbn() + "'";

		try {

			//Connectionオブジェクトを生成
			con = BookDAO.getConnection();

			//Statementオブジェクトを生成
			smt = con.createStatement();

			//SQLをDBへ移行
			smt.executeUpdate(sql);


		}catch(Exception e) {
			throw new IllegalStateException (e);
		}finally {

			//Statementオブジェクトをクローズ
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}

			//Connectionオブジェクトをクローズ
			if(con != null) {
				try {con.close();}catch(SQLException ignore) {}
			}
		}
	}

	//検索
	public ArrayList<Book> search(String isbn,String title, String price){

		//変数宣言
		Connection con = null;
		Statement smt = null;

		//ArrayListオブジェクトを生成
		ArrayList<Book> bookList = new ArrayList<Book>();

		//SQL文を文字列として定義
		String sql = "SELECT isbn,title,price FROM bookinfo " +
				"WHERE isbn LIKE '%" + isbn + "%' AND"
				+ " title LIKE '%" + title + "%' AND"
				+ " price LIKE '%" + price + "%'";


		//String sql = "SELECT * FROM bookinfo ORDER BY ISBN";

		try {

			//Connectionオブジェクトを生成
			con = BookDAO.getConnection();

			//Statementオブジェクトを生成
			smt = con.createStatement();

			//SQL文を発行
			ResultSet rs = smt.executeQuery(sql);

			//書籍データを検索分すべて取り出す
			while(rs.next()){
				Book book = new Book();
				book.setIsbn(rs.getString("isbn"));
				book.setTitle(rs.getString("title"));
				book.setPrice(rs.getInt("price"));

				//ArrayListオブジェクトにBookオブジェクトとして格納
				bookList.add(book);
			}


		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally{

			//statementオブジェクトをクローズ
			if(smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}

			//Connectionオブジェクトをクローズ
			if(con != null) {
				try {con.close();}catch(SQLException ignore) {}
			}
		}
		return bookList;
	}


}
